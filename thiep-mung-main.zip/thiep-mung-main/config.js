const nameGirl = 'Vợ iu';
const giftUrl = 'http://nodemy.vn';
const eventName = 'Chúc Mừng 8-3';
const titleCard = 'Tặng vợ tui';
const contentCard = 'Chúc vợ của anh 8/3 tràn ngập tràn niềm vui và những nụ cười. Mong điều đẹp nhất sẽ đến với vợ trong hôm nay và cả những ngày sau. Anh nhớ em nhiều lắm, iu em!;

// phần dưới dành cho các bạn biết code, nếu muốn chỉnh ảnh đơn giản với base64
// Cần hỗ trợ hãy liên hệ: 
// Mr-Nam http://facebook.com/nam.nodemy
// Các bạn muốn học lập trình thì tham gia Nhóm zalo tự học lập trình nhé: https://zalo.me/g/yhdkef092
const giftImage = 'hot-girlpiupiu.webp';
const base64 = '';
const giftImageBase64 = "data:image/png;base64, " + base64;
